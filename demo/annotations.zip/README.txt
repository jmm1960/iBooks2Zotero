iBooks2Zotero annotation bundle

Select this ZIP as the source in iBooks2Zotero. A matching target PDF is still required.
Page indices are zero-based; filenames use one-based PDF pages.
*.strokes.json uses PDF coordinates; *.notes.json contains highlights and notes.
*.apple.plist preserves original Apple drawing archives. *.drawing is decoded PencilKit data. *.png is an approximate stroke preview; *.preview.json gives its drawing-space bounds.
No book pages, PDF content, or grouping settings are included.
Legacy bundles have no source fingerprints and require manual edition confirmation.
