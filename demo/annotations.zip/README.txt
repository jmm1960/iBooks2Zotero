iBooks2Zotero raw annotation archive

annotations.pdf contains the original PDF annotation objects and their referenced appearance/resource streams on blank pages. The book page content is intentionally excluded. Unknown annotation types and opaque Apple drawing archives are retained without handwriting decoding, resampling, grouping, flattening, or appearance regeneration.

manifest.json records original page positions, document fingerprints, source-file SHA-256 and payload SHA-256. Select this ZIP as the source and a matching target PDF in Zotero; conversion happens only when importing/previewing.

PDF object numbers, cross-reference tables and container serialization are regenerated. This is not a byte-for-byte copy of the full source PDF and does not retain valid signatures over that source file. Keep the original PDF when that is required.
